#读取文件
a<-read.csv("D:/R语言在生物信息学的应用/ADdata/ADdata1.txt",sep="\t",row.names = NULL)
names(a)[1]="ID"  #为第一列命名以便后续合并
b<-read.csv("D:/R语言在生物信息学的应用/ADdata/ADdata2.csv")
names(b)[1]="ID"
library(openxlsx)
c<-read.xlsx("D:/R语言在生物信息学的应用/ADdata/ADdata3.xlsx")
names(c)[1]="ID"
d<-read.table("D:/R语言在生物信息学的应用/ADdata/ADdata4.txt",row.names = NULL)
names(d)[1]="ID"

#设置与查看输出路径
setwd("D:/R语言在生物信息学的应用/ADdata")
getwd()

#使用merge函数两两合并数据
e<-merge(a,d,by="ID")
write.csv(e,file ="合并1.csv" ,row.names = FALSE)
f<-merge(b,c,by="ID")
g<-merge(e,f,by="ID",row.names=FALSE)  #最终合并的数据

#保存为csv文件
write.csv(g,file ="合并.csv" ,row.names = FALSE)

#保存为xlsx文件
write.xlsx(g,file ="合并.xlsx" )

#保存为txt文件
write.table(g,file="合并.txt")
