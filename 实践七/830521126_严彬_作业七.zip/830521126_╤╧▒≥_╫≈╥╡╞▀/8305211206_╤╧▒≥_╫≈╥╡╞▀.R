library(Seurat)
library(ggplot2)
#读取文件
pbmc.data <- Read10X(data.dir = "C:\\Users\\yb0410\\Desktop\\R实践七\\pbmc3k_filtered_gene_bc_matrices\\filtered_gene_bc_matrices\\hg19\\")
#使用CreateSeuratObject函数创建seurat对象,过滤条件是细胞中基因数目不能小于200，且基因至少在三个细胞中有表达
pbmc<-CreateSeuratObject(counts=pbmc.data,project = "pbmc3k",min.cells =3,min.features = 200 )
#计算线粒体基因比例
pbmc[['percent.mt']]<-PercentageFeatureSet(pbmc,pattern="^MT-|^mt-")
#使用Vlnplot函数对QC指标可视化
VlnPlot(pbmc,features=c("nFeature_RNA","nCount_RNA","percent.mt"),ncol=3)
#数据标准化处理
pbmc<-subset(pbmc,subset= nFeature_RNA>200& nFeature_RNA<2500&percent.mt<5)
# 数据标准化处理
pbmc<-NormalizeData(pbmc,normalization.method="LogNormalize",scale.factor = 10000)
#数据归一化
all.genes<-rownames(pbmc)
pbmc<-ScaleData(pbmc,features = all.genes)
# 找出高变基因 
pbmc<-FindVariableFeatures(pbmc,selection.method = "vst",nFeature=2000)
#绘制高变基因的可视化图  
VariableFeaturePlot(pbmc)
top10<-head(VariableFeaturePlot(pbmc),10)
#主成分分析
pbmc<-RunPCA(pbmc,features=VariableFeatures(object=pbmc))
#细胞聚类
pbmc<-FindNeighbors(pbmc,dims=1:10)
#根据PCA结果将细胞分成不同的簇  
pbmc<-FindClusters(pbmc,resolution = 0.5)
#绘制聚类结果的UMAP图  
pbmc<-RunUMAP(pbmc,dims=1:10)
UMAPPlot(pbmc)
#差异表达分析，提取每个簇中差异表达最显著的2个基因  
pbmc.markers<-FindAllMarkers(pbmc,only.pos = TRUE,min.pct=0.25,logfc.threshold=0.25)
top_markers <- pbmc.markers %>%  
  group_by(cluster) %>%  
  slice_max(n=2,order_by=avg_log2FC)%>%  
  select(cluster, gene, avg_log2FC) 
# 绘制top2基因的DotPlot图
p10<-DotPlot(object=pbmc,assay = "RNA",features = top_markers$gene)+
  theme(axis.text.x=element_text(angle=45,hjust=1))
print(p10)
# 关闭图形设备 
dev.off()
#挑选基因绘制小提琴图
VlnPlot(pbmc,features=c("CCR7","AQP3","GZMK","CKB","FCER1A","GZMH"))
#挑选基因绘制Feature图
FeaturePlot(pbmc,features = c("CCR7","AQP3","GZMK","CKB","FCER1A","GZMH"))
